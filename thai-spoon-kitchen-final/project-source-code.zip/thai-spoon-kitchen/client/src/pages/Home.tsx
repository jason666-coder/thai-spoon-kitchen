import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { MapPin, Phone, Mail, Star, Send } from 'lucide-react';
import { toast } from 'sonner';

/**
 * Design Philosophy: Warm Minimalism with Thai Heritage
 * - Thai-inspired color palette: Gold (#D4A574), Terracotta (#C17A6B), Cream (#FFFBF5)
 * - Playfair Display for headings, Inter for body text
 * - Asymmetric layouts with generous whitespace
 * - Conversion-focused with repeated CTAs throughout
 */

export default function Home() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
  });

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email) {
      toast.error('Please enter your email');
      return;
    }
    toast.success('Thank you! We\'ll send you special offers soon.');
    setFormData({ name: '', email: '', phone: '' });
  };

  const [, navigate] = useLocation();

  const handleViewMenuClick = () => {
    navigate('/menu');
  };

  const handleVisitUsClick = () => {
    // Open Google Maps with the restaurant location
    window.open('https://www.google.com/maps/place/Thai+Spoon+Kitchen+%26+Cafe/@4.2472753,117.855554,17427m/data=!3m1!1e3!4m10!1m2!2m1!1srestaurants!3m6!1s0x32159d788d0356ad:0x35b6de7c03e571cf!8m2!3d4.2734663!4d117.8976586!15sCgtyZXN0YXVyYW50c1oNIgtyZXN0YXVyYW50c5IBD3RoYWlfcmVzdGF1cmFudJoBRENpOURRVWxSUVVOdlpFTm9kSGxqUmpsdlQyMTRjVmxVVGxOWlZGWktaVWRqZVdGcVRtNWxSRTUzWTJwS1YxTnNSUkFC4AEA-gEFCJ8BEEc!16s%2Fg%2F11vc87f0zf?entry=ttu&g_ep=EgoyMDI2MDMyNC4wIKXMDSoASAFQAw%3D%3D', '_blank');
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 w-full bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary">Thai Spoon Kitchen</h1>
          <div className="flex gap-4 items-center">
            <button
              onClick={() => navigate('/')}
              className="text-foreground hover:text-primary transition font-semibold"
            >
              Home
            </button>
            <button
              onClick={() => navigate('/menu')}
              className="text-foreground hover:text-primary transition font-semibold"
            >
              Menu
            </button>
            <a
              href="tel:+60165766612"
              className="bg-primary text-primary-foreground px-6 py-2 rounded-lg font-semibold hover:shadow-lg transition"
            >
              Call Us
            </a>
          </div>
        </div>
      </nav>

      {/* ===== SECTION 1: HERO ===== */}
      <section className="relative w-full overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663487079569/gGLtCezYpoxwhP8ttbJJaQ/hero-background-ZYFw4At3U6QU6RBNcZM6A6.webp)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <div className="absolute inset-0 bg-black/30" />
        </div>

        {/* Content */}
        <div className="relative z-10 container mx-auto px-4 py-24 md:py-32 flex flex-col justify-center min-h-[600px]">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
              Authentic Thai Flavors, Right Here in Town 🇹🇭
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 font-light">
              Fresh ingredients, bold spices, and a cozy cafe experience — loved by locals and visitors alike.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={handleViewMenuClick}
                className="cta-button text-lg px-10 py-4"
              >
                View Menu
              </Button>
              <Button
                onClick={handleVisitUsClick}
                className="cta-button-secondary text-lg px-10 py-4"
              >
                Visit Us Today
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ===== SECTION 2: SOCIAL PROOF ===== */}
      <section className="w-full py-20 md:py-28 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Loved by Food Lovers ❤️
            </h2>
            <div className="flex justify-center items-center gap-2 mb-8">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-primary text-primary" />
              ))}
            </div>
            <p className="text-lg text-muted-foreground">
              Join hundreds of satisfied customers who've experienced authentic Thai cuisine
            </p>
          </div>

          {/* Testimonials */}
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                text: "Best Thai food I've had in Malaysia — super authentic!",
                author: 'Sarah Chen',
              },
              {
                text: 'Cozy vibe, amazing flavors. Will come again!',
                author: 'Michael Rodriguez',
              },
              {
                text: 'Their tom yum is a must-try 🔥',
                author: 'Emma Thompson',
              },
            ].map((review, idx) => (
              <Card key={idx} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <p className="text-foreground mb-4 italic">"{review.text}"</p>
                  <p className="font-semibold text-primary">— {review.author}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ===== SECTION 3: SIGNATURE DISHES ===== */}
      <section className="w-full py-20 md:py-28 bg-secondary/20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-center">
            Our Most Loved Dishes
          </h2>
          <p className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
            Experience the authentic flavors that have made us a local favorite
          </p>

          {/* Dishes Grid */}
          <div className="mb-12">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663487079569/gGLtCezYpoxwhP8ttbJJaQ/signature-dishes-85bKGgHVRw6wx7ehLHekp6.webp"
              alt="Signature Dishes: Pad Thai, Tom Yum, Green Curry, Mango Sticky Rice"
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>

          {/* Dish Names */}
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            {['Pad Thai', 'Tom Yum Soup', 'Green Curry', 'Mango Sticky Rice'].map((dish) => (
              <div key={dish} className="text-center">
                <h3 className="text-xl font-semibold text-primary mb-2">{dish}</h3>
                <p className="text-sm text-muted-foreground">
                  Authentic recipe, fresh ingredients
                </p>
              </div>
            ))}
          </div>

          <div className="text-center flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleViewMenuClick}
              className="cta-button text-lg px-10 py-4"
            >
              View Menu
            </Button>
            <Button
              onClick={handleVisitUsClick}
              className="cta-button-secondary text-lg px-10 py-4"
            >
              Visit Us Today
            </Button>
          </div>
        </div>
      </section>

      {/* ===== SECTION 4: LOCATION & CONVENIENCE ===== */}
      <section className="w-full py-20 md:py-28 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Easy to Find, Hard to Forget
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Conveniently located and easy to access — perfect for dine-in or takeaway.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-4">
                  <MapPin className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold">Visit Us</p>
                    <p className="text-muted-foreground">
                      Lot No.10, Kuhara Industrial, Jalan Air Panas, 91000 Tawau, Sabah
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Phone className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold">Call Us</p>
                    <p className="text-muted-foreground">
                      <a href="tel:+60165766612" className="hover:text-primary transition">
                        +60 16 576 6612
                      </a>
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold">Hours</p>
                    <p className="text-muted-foreground">
                      11:30 AM - 10:00 PM Daily
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleViewMenuClick}
                  className="cta-button text-lg px-10 py-4"
                >
                  View Menu
                </Button>
                <Button
                  onClick={handleVisitUsClick}
                  className="cta-button-secondary text-lg px-10 py-4"
                >
                  Visit Us Today
                </Button>
              </div>
            </div>

            {/* Map Embed */}
            <div className="rounded-lg overflow-hidden shadow-lg h-96">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.7343999999998!2d117.8976586!3d4.2734663!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x32159d788d0356ad%3A0x35b6de7c03e571cf!2sThai%20Spoon%20Kitchen%20%26%20Cafe!5e0!3m2!1sen!2smy!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>

      {/* ===== SECTION 5: LEAD CAPTURE FORM ===== */}
      <section className="w-full py-20 md:py-28 bg-secondary/20">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold mb-4">
                Get Special Offers & Updates 🎁
              </h2>
              <p className="text-lg text-muted-foreground">
                Get exclusive discounts and new menu updates.
              </p>
            </div>

            <Card className="border-0 shadow-lg">
              <CardContent className="pt-8">
                <form onSubmit={handleFormSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="name" className="text-base font-semibold">
                      Name (Optional)
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      placeholder="Your name"
                      value={formData.name}
                      onChange={handleFormChange}
                      className="mt-2 h-12 text-base"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-base font-semibold">
                      Email *
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={handleFormChange}
                      className="mt-2 h-12 text-base"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone" className="text-base font-semibold">
                      Phone (Optional)
                    </Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      placeholder="+60 123 456 789"
                      value={formData.phone}
                      onChange={handleFormChange}
                      className="mt-2 h-12 text-base"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full cta-button text-lg py-4 flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    Subscribe for Offers
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* ===== SECTION 6: ATMOSPHERE / EXPERIENCE ===== */}
      <section className="w-full py-20 md:py-28 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Image */}
            <div className="order-2 md:order-1">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663487079569/gGLtCezYpoxwhP8ttbJJaQ/restaurant-interior-FsztuKSqNPvZcZBCAVys3L.webp"
                alt="Cozy Thai restaurant interior with warm lighting and comfortable seating"
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>

            {/* Content */}
            <div className="order-1 md:order-2">
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                More Than Just Food
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Located in Tawau, Sabah, we offer authentic Thai cuisine in a warm, welcoming environment. Open daily from 11:30 AM to 10:00 PM for dine-in and takeaway.
              </p>

              <div className="space-y-6 mb-8">
                <div>
                  <h3 className="text-xl font-semibold text-primary mb-2">Open Daily</h3>
                  <p className="text-muted-foreground">
                    11:30 AM - 10:00 PM. Perfect for lunch, dinner, or a casual coffee break with friends.
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-primary mb-2">Easy to Find</h3>
                  <p className="text-muted-foreground">
                    Located at Lot No.10, Kuhara Industrial, Jalan Air Panas, Tawau. Convenient parking available for all guests.
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-primary mb-2">Call Ahead</h3>
                  <p className="text-muted-foreground">
                    Phone: <a href="tel:+60165766612" className="text-primary hover:underline">+60 16 576 6612</a> for reservations or takeaway orders.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleViewMenuClick}
                  className="cta-button text-lg px-10 py-4"
                >
                  View Menu
                </Button>
                <Button
                  onClick={handleVisitUsClick}
                  className="cta-button-secondary text-lg px-10 py-4"
                >
                  Visit Us Today
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== SECTION 7: FINAL CTA BANNER ===== */}
      <section
        className="w-full py-24 md:py-32 relative overflow-hidden"
        style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663487079569/gGLtCezYpoxwhP8ttbJJaQ/cta-banner-hJK43VjQcW8WrRW7TsXnXs.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Craving Thai Food Right Now?
          </h2>
          <p className="text-xl md:text-2xl text-white/90 mb-8 font-light">
            Come visit us today and experience authentic flavors that will transport your taste buds to Thailand.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleViewMenuClick}
              className="cta-button text-lg px-10 py-4"
            >
              View Menu
            </Button>
            <Button
              onClick={handleVisitUsClick}
              className="cta-button-secondary text-lg px-10 py-4"
            >
              Visit Us Today
            </Button>
          </div>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="w-full py-12 bg-foreground text-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Thai Spoon Kitchen & Cafe</h3>
              <p className="text-background/80">
                Authentic Thai cuisine in a cozy cafe setting. Fresh ingredients, bold spices, unforgettable flavors. Located in Tawau, Sabah.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Hours & Location</h3>
              <ul className="space-y-2 text-background/80">
                <li>Open Daily: 11:30 AM - 10:00 PM</li>
                <li>Lot No.10, Kuhara Industrial</li>
                <li>Jalan Air Panas, 91000 Tawau, Sabah</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <p className="text-background/80 mb-2">
                <a href="tel:+60165766612" className="hover:text-background transition">
                  +60 16 576 6612
                </a>
              </p>
              <p className="text-background/80 text-sm">
                Call for reservations or takeaway orders
              </p>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-background/60">
            <p>&copy; 2026 Thai Spoon Kitchen & Cafe. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
