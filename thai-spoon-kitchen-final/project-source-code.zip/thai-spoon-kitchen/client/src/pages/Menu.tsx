import { useState } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChefHat, Droplets } from 'lucide-react';
import { toast } from 'sonner';

/**
 * Design Philosophy: Warm Minimalism with Thai Heritage
 * Menu page showcasing all dishes with organized categories
 */

interface MenuItem {
  name: string;
  price: string;
}

interface MenuCategory {
  title: string;
  icon: React.ReactNode;
  items: MenuItem[];
}

export default function Menu() {
  const [, navigate] = useLocation();
  const [activeCategory, setActiveCategory] = useState('fish');

  const menuData: Record<string, MenuCategory> = {
    fish: {
      title: 'Ikan (Fish)',
      icon: <ChefHat className="w-6 h-6" />,
      items: [
        { name: 'Ikan Bakar Kicap Manis', price: 'RM 30.00' },
        { name: 'Ikan Bakar Tom Yam', price: 'RM 40.00' },
        { name: 'Ikan Bakar Three Style', price: 'RM 45.00' },
        { name: 'Ikan Stim Halia', price: 'RM 35.00' },
        { name: 'Ikan Stim Limau Thai', price: 'RM 38.00' },
        { name: 'Ikan Stim Thai', price: 'RM 36.00' },
        { name: 'Ikan Kari', price: 'RM 38.00' },
        { name: 'Ikan Masak Lemak', price: 'RM 36.00' },
        { name: 'Ikan Masak Asam Boi', price: 'RM 35.00' },
        { name: 'Ikan Masak Kam Heong', price: 'RM 40.00' },
        { name: 'Ikan Goreng Tiga Rasa', price: 'RM 32.00' },
        { name: 'Ikan Goreng Salted Egg', price: 'RM 34.00' },
        { name: 'Ikan Goreng Thai', price: 'RM 30.00' },
      ],
    },
    crab: {
      title: 'Ketam (Crab)',
      icon: <ChefHat className="w-6 h-6" />,
      items: [
        { name: 'Ketam Tiga Rasa', price: 'RM 68.00/600g' },
        { name: 'Ketam Masak Lemak', price: 'RM 72.00/600g' },
        { name: 'Ketam Kam Heong', price: 'RM 70.00/600g' },
        { name: 'Ketam Black Pepper', price: 'RM 75.00/600g' },
        { name: 'Ketam Salted Egg', price: 'RM 78.00/600g' },
        { name: 'Ketam Goreng Tiga Rasa', price: 'RM 65.00/600g' },
        { name: 'Ketam Siam', price: 'RM 80.00/600g' },
      ],
    },
    meat: {
      title: 'Daging (Meat)',
      icon: <ChefHat className="w-6 h-6" />,
      items: [
        { name: 'Daging Tumis Pedas Thai', price: 'RM 22.90' },
        { name: 'Ayam Tumis Pedas Kicap', price: 'RM 18.90' },
        { name: 'Daging Tumis Pedas Thai Pedas Thai', price: 'RM 23.90' },
      ],
    },
    squid: {
      title: 'Sotong (Squid)',
      icon: <ChefHat className="w-6 h-6" />,
      items: [
        { name: 'Sotong Bakar', price: 'RM 14.90' },
        { name: 'Sotong Goreng Tiga Rasa', price: 'RM 16.90' },
        { name: 'Sotong Goreng Tepung', price: 'RM 13.90' },
        { name: 'Sotong Goreng Salted Egg', price: 'RM 17.90' },
      ],
    },
    salad: {
      title: 'Kerabu (Salad)',
      icon: <ChefHat className="w-6 h-6" />,
      items: [
        { name: 'Kerabu Belacan', price: 'RM 14.90' },
        { name: 'Kerabu Kacang Botol', price: 'RM 15.90' },
        { name: 'Kerabu Betik', price: 'RM 13.90' },
        { name: 'Kerabu Sotong', price: 'RM 16.90' },
        { name: 'Kerabu Daging', price: 'RM 17.90' },
        { name: 'Kerabu Pokok', price: 'RM 12.90' },
      ],
    },
    tea: {
      title: 'Teh (Tea)',
      icon: <Droplets className="w-6 h-6" />,
      items: [
        { name: 'Teh Tarik Panas', price: 'RM 5.90' },
        { name: 'Teh Tarik Ais', price: 'RM 6.90' },
        { name: 'Teh Tarik Float', price: 'RM 10.90' },
      ],
    },
    smoothie: {
      title: 'Jus & Smoothie (Juice & Smoothie)',
      icon: <Droplets className="w-6 h-6" />,
      items: [
        { name: 'Smoothie Pisang Karamel', price: 'RM 16.00' },
        { name: 'Smoothie Buah Markisa', price: 'RM 18.00' },
        { name: 'Smoothie Buah Naga', price: 'RM 19.00' },
        { name: 'Jus Buah', price: 'RM 10.00' },
        { name: 'Smoothie Mangga', price: 'RM 18.00' },
        { name: 'Smoothie Strawberry', price: 'RM 19.90' },
        { name: 'Smoothie Latte', price: 'RM 18.90' },
        { name: 'Smoothie Buah Cempedak', price: 'RM 18.90' },
        { name: 'Smoothie Jambu', price: 'RM 16.90' },
      ],
    },
    soda: {
      title: 'Soda (Soda)',
      icon: <Droplets className="w-6 h-6" />,
      items: [
        { name: 'Soda Buah Naga', price: 'RM 10.90' },
        { name: 'Soda Buah Terung', price: 'RM 10.90' },
        { name: 'Soda Buah Belimbing', price: 'RM 10.90' },
        { name: 'Soda Limau', price: 'RM 9.90' },
        { name: 'Soda Buah Mangga', price: 'RM 10.90' },
        { name: 'Soda Buah Strawberry', price: 'RM 10.90' },
        { name: 'Soda Buah Kersen', price: 'RM 10.90' },
        { name: 'Soda Buah Blueberry', price: 'RM 10.90' },
      ],
    },
  };

  const categories = Object.entries(menuData).map(([key, value]) => ({
    key,
    ...value,
  }));

  const currentMenu = menuData[activeCategory];

  const handleOrderClick = () => {
    toast.info('Call us at +60 16 576 6612 to place your order!');
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 w-full bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary">Thai Spoon Kitchen</h1>
          <div className="flex gap-4 items-center">
            <button
              onClick={() => navigate('/')}
              className="text-foreground hover:text-primary transition font-semibold"
            >
              Home
            </button>
            <button
              onClick={() => navigate('/menu')}
              className="text-foreground hover:text-primary transition font-semibold"
            >
              Menu
            </button>
            <a
              href="tel:+60165766612"
              className="bg-primary text-primary-foreground px-6 py-2 rounded-lg font-semibold hover:shadow-lg transition"
            >
              Call Us
            </a>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="w-full py-16 md:py-24 bg-gradient-to-r from-primary/10 to-accent/10 border-b-2 border-primary/20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Our Menu</h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            Explore our authentic Thai cuisine with fresh ingredients and bold flavors. All dishes are prepared to order.
          </p>
        </div>
      </section>

      {/* Menu Content */}
      <section className="w-full py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            {/* Category Navigation */}
            <div className="md:col-span-1">
              <div className="sticky top-8">
                <h3 className="text-xl font-bold mb-6 text-primary">Categories</h3>
                <div className="space-y-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.key}
                      onClick={() => setActiveCategory(cat.key)}
                      className={`w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                        activeCategory === cat.key
                          ? 'bg-primary text-primary-foreground font-semibold'
                          : 'bg-secondary/50 text-foreground hover:bg-secondary'
                      }`}
                    >
                      {cat.title}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Menu Items */}
            <div className="md:col-span-3">
              <Card className="border-0 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
                  <div className="flex items-center gap-3">
                    <div className="text-primary">{currentMenu.icon}</div>
                    <CardTitle className="text-3xl">{currentMenu.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-8">
                  <div className="grid gap-4">
                    {currentMenu.items.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex justify-between items-start pb-4 border-b border-border/50 last:border-b-0 hover:bg-secondary/30 px-2 py-2 rounded transition-colors"
                      >
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">{item.name}</p>
                        </div>
                        <p className="text-primary font-bold ml-4 whitespace-nowrap">{item.price}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 pt-8 border-t border-border">
                    <p className="text-sm text-muted-foreground mb-4">
                      Ready to order? Call us or visit us in person!
                    </p>
                    <Button
                      onClick={handleOrderClick}
                      className="cta-button w-full text-lg py-4"
                    >
                      Order Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="w-full py-16 md:py-24 bg-secondary/20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-md">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-3 text-primary">Fresh Ingredients</h3>
                <p className="text-muted-foreground">
                  We use only the freshest ingredients sourced daily to ensure the best quality in every dish.
                </p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-3 text-primary">Authentic Recipes</h3>
                <p className="text-muted-foreground">
                  Our recipes are inspired by traditional Thai cuisine, prepared by experienced chefs.
                </p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-md">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-3 text-primary">Customizable</h3>
                <p className="text-muted-foreground">
                  Have dietary preferences? We can customize most dishes to suit your needs.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section
        className="w-full py-20 md:py-28 relative overflow-hidden"
        style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663487079569/gGLtCezYpoxwhP8ttbJJaQ/cta-banner-hJK43VjQcW8WrRW7TsXnXs.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Ready to Taste Authentic Thai?
          </h2>
          <p className="text-lg md:text-xl text-white/90 mb-8">
            Visit us today or call for takeaway orders
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => window.location.href = 'tel:+60165766612'}
              className="cta-button text-lg px-10 py-4"
            >
              Call to Order
            </Button>
            <Button
              onClick={() => window.location.href = '/'}
              className="cta-button-secondary text-lg px-10 py-4"
            >
              Visit Us
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full py-12 bg-foreground text-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Thai Spoon Kitchen & Cafe</h3>
              <p className="text-background/80">
                Authentic Thai cuisine in a cozy cafe setting. Fresh ingredients, bold spices, unforgettable flavors.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Hours & Location</h3>
              <ul className="space-y-2 text-background/80">
                <li>Open Daily: 11:30 AM - 10:00 PM</li>
                <li>Lot No.10, Kuhara Industrial</li>
                <li>Jalan Air Panas, 91000 Tawau, Sabah</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <p className="text-background/80 mb-2">
                <a href="tel:+60165766612" className="hover:text-background transition">
                  +60 16 576 6612
                </a>
              </p>
              <p className="text-background/80 text-sm">
                Call for reservations or takeaway orders
              </p>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-background/60">
            <p>&copy; 2026 Thai Spoon Kitchen & Cafe. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
